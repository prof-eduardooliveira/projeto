VistaICO Toolbar Icons
from VistaICO.com


This pack contains 50 quality icons (arrows, cut, copy, help, symbols...) which can be used in applications, websites or other projects.



IMPORTANT!
- This pack is licensed under a Creative Commons Attribution 3.0 License. This means you may copy, distribute and adapt the work as long as you include a link back to VistaICO.com in your web site, software, project, etc. Here you can find few examples:
http://www.vistaico.com/link_to_us.htm

- To contact us regarding the link placement or other matters please check here:
http://www.vistaico.com/contact.htm

- The readme.txt and license.pdf files must accompany the pack at all times.



Copyright � VistaICO.com