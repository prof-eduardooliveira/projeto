package scoop;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

interface ImageListUser {
  public void imageSelected(ImagePanel imgPan);
}
class ImagePanel extends JPanel implements MouseListener {
  private String filePath=null;
  private ImageListUser ilu=null;
  private Image image=null;
  private Dimension imgDim=null;


  public ImagePanel() {}
  public ImagePanel(String filePath, Image image,
                    Dimension imgDim, ImageListUser ilu) {
    setValues(filePath, image, imgDim, ilu);
  }

  public String getFilePath() {
    return this.filePath;
  }
  public Dimension getImageDim() {
    return imgDim;
  }
  public Dimension getPreferredSize() {
    return imgDim;
  }
  public void setValues(String filePath, Image image,
                        Dimension imgDim, ImageListUser ilu) {
    this.filePath=filePath;
    this.ilu=ilu;
    this.image=image;
    this.imgDim=imgDim;
    this.addMouseListener(this);
  }
  public void update(Graphics g) {
    Color c=g.getColor();
    g.setColor(Color.white);
    g.fillRect(0,0,getWidth(),getHeight());
    g.drawImage(image,0,0,this);
    g.setColor(c);
  }
  public void paint(Graphics g) {
    update(g);
  }

  public void mouseClicked(MouseEvent e) {
    ilu.imageSelected(this);
  }
  public void mousePressed(MouseEvent e) { }
  public void mouseReleased(MouseEvent e) {}
  public void mouseEntered(MouseEvent e) {}
  public void mouseExited(MouseEvent e) {}

}
public class HorzontalImageScroll extends JFrame
    implements ImageListUser, ActionListener {

  private ImagePanel currentSelectedPanel=null;

  BorderLayout borderLayout1 = new BorderLayout();
  JPanel jPanel1 = new JPanel();
  JButton loadBtn = new JButton();
  JTextField imgPathTF = new JTextField();
  JButton remBtn = new JButton();
  JScrollPane imgScroller = new JScrollPane();
  JPanel scrollerPanel = new JPanel();
  FlowLayout flowLayout1 = new FlowLayout();

  public HorzontalImageScroll() {
    try {
      jbInit();
      remBtn.addActionListener(this);
      loadBtn.addActionListener(this);
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  public void imageSelected(ImagePanel imgPan) {
    JOptionPane.showMessageDialog(this,"You selected: "+imgPan.getFilePath(),
                                  "Image selected",
                                  JOptionPane.INFORMATION_MESSAGE);
    currentSelectedPanel=imgPan;
  }
  /**
   * Show filedialog, get selcted image
   */
  private void getSelectedImage() {
    FileDialog fd = new FileDialog(this, "Select image", FileDialog.LOAD);
    fd.setVisible(true);
    String fn = fd.getFile();
    if (fn == null)  return;

    String fPath = fd.getDirectory() + fn;
    byte[] b = null;
    try {
      FileInputStream in = new FileInputStream(fPath);
      int n = in.available();
      if (n == 0) {
        return;
      }
      b = new byte[n];
      in.read(b);
      in.close();
    }
    catch (IOException ex1) {
      ex1.printStackTrace();
      return;
    }
    Image img = Toolkit.getDefaultToolkit().createImage(b);
    MediaTracker mt = new MediaTracker(this);
    mt.addImage(img, 0);
    try {
      mt.waitForAll();
      Dimension dim=new Dimension(img.getWidth(this), img.getHeight(this));
      ImagePanel iPan = new ImagePanel(fPath, img, dim, this);
      scrollerPanel.add(iPan);
      setPreferredScrollerDIm();
    }
    catch (InterruptedException ex) {
      ex.printStackTrace();
    }

  }
  /**
   * Get the size required for the gridPanel by checking the size of
   * the imagepanels stored there.
   */
  private void setPreferredScrollerDIm() {
    FlowLayout fl=(FlowLayout)scrollerPanel.getLayout();
    int hGap=fl.getHgap();
    Component [] cmp=scrollerPanel.getComponents();
    Dimension prefDim=new Dimension(0,0);
    for (int i=0; i<cmp.length; i++) {
      if (cmp[i] instanceof ImagePanel) {
        ImagePanel iPan=(ImagePanel)cmp[i];
        if (iPan.getImageDim().height > prefDim.height) {
          prefDim.height=iPan.getImageDim().height;
        }
        prefDim.width += iPan.getImageDim().width+hGap;
      }
    }
    scrollerPanel.setPreferredSize(prefDim);
    imgScroller.validate();
  }
  public void actionPerformed (ActionEvent ae) {
    if (ae.getSource()==loadBtn) {
      getSelectedImage();
    } else if (ae.getSource()==remBtn) {
      if (currentSelectedPanel==null) return;
      scrollerPanel.remove(currentSelectedPanel);
      setPreferredScrollerDIm();
    }
  }
  void jbInit() throws Exception {
    this.getContentPane().setLayout(borderLayout1);
    loadBtn.setText("Load");
    imgPathTF.setText("");
    imgPathTF.setColumns(22);

    remBtn.setText("Remove");
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    imgScroller.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    imgScroller.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
    scrollerPanel.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.LEFT);
    this.getContentPane().add(jPanel1, BorderLayout.SOUTH);
    jPanel1.add(remBtn, null);
    jPanel1.add(loadBtn, null);
    jPanel1.add(imgPathTF, null);
    this.getContentPane().add(imgScroller, BorderLayout.CENTER);
    imgScroller.getViewport().add(scrollerPanel, null);
  }
  public static void main (String [] args) {
    HorzontalImageScroll his=new HorzontalImageScroll();
    his.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    his.setBounds(20,20,700,300);
    his.setVisible(true);
  }

}

